# Copyright...
from controller import Supervisor
import math

class KinematicRobot(Supervisor):
    def __init__(self):
        Supervisor.__init__(self)

        self.time_step = int(self.getBasicTimeStep())
        self.robot_node = self.getSelf()

        # CONSTANTS
        self.SPEED = 5
        self.TURN_SPEED = 1.5
        self.HAZARD_DISTANCE = 0.8
        self.MIN_SAFE_RADIUS = 1.0    # m, when robot is very slow
        self.MAX_SAFE_RADIUS = 3.0    # m, when robot is at max speed
        self.MAX_SPEED = self.SPEED   

        # STATE
        self.trans_field = self.robot_node.getField("translation")
        self.rot_field = self.robot_node.getField("rotation")

        # Initial pose
        pos = self.trans_field.getSFVec3f()
        rot = self.rot_field.getSFRotation()

        self.x = pos[0]
        self.y = pos[1]
        self.theta = rot[3]

        self.LOCKED_Z = 0.11

        # DEVICES
        self.lidar = self.getDevice("lidar")
        self.lidar.enable(self.time_step)
        self.lidar.enablePointCloud()

        self.camera = self.getDevice("camera")
        self.camera.enable(self.time_step)

        self.imu = self.getDevice("inertial_unit")
        self.imu.enable(self.time_step)

        # AUTONOMY STATE MACHINE
        self.state = "FORWARD"
        self.turn_target = None   # used for smooth PID turning

        # ---------- MANY WORKERS GROUND-TRUTH ----------
        # assumes DEF WORKER1 ... WORKER11 in Webots
        self.workers = []  # each item: {"name","trans","x","y"}

        for i in range(1, 12):  # 1..11
            name = f"WORKER{i}"
            node = self.getFromDef(name)
            if node is not None:
                trans = node.getField("translation")
                self.workers.append({
                    "name": name,
                    "trans": trans,
                    "x": None,
                    "y": None,
                    "active": True,      # status
                    "missed_steps": 0,    # how many steps not seen
                    "path": []            # trajectory history
                })

        # ---------- LOG FILE ----------
        self.log_file = open("/Users/azhagunatarajak/Documents/hazard_log.csv", "w")
        self.log_file.write("time,x,y,theta,front,left,right,danger,worker_hazard,closest_worker_dist,state\n")
        # --------------------------------------

    # ------------------------------------------------------
    #      LIDAR HAZARD CHECK (Point Cloud Based)
    # ------------------------------------------------------
    def get_lidar_sectors(self):
        pc = self.lidar.getPointCloud()
        left = []
        front = []
        right = []

        for p in pc:
            x = p.x
            y = p.y

            dist = math.sqrt(x*x + y*y)
            angle = math.atan2(y, x)

            # sector classification
            if -0.5 < angle < 0.5:
                front.append(dist)
            elif angle >= 0.5:
                left.append(dist)
            else:
                right.append(dist)

        def safe_min(lst):
            return min(lst) if lst else 99.0

        return {
            "LEFT": safe_min(left),
            "FRONT": safe_min(front),
            "RIGHT": safe_min(right)
        }

    # ------------------------------------------------------
    #         SMOOTH TURN CONTROLLER (PID-like)
    # ------------------------------------------------------
    def smooth_turn(self, target_angle, dt):
        error = target_angle - self.theta
        error = (error + math.pi) % (2*math.pi) - math.pi  # normalize

        kP = 2.0
        angular_v = kP * error

        # clamp
        if angular_v > self.TURN_SPEED:
            angular_v = self.TURN_SPEED
        if angular_v < -self.TURN_SPEED:
            angular_v = -self.TURN_SPEED

        return angular_v, abs(error) < 0.05  # return: (angular speed, finished?)

    # ------------------------------------------------------
    #                     MAIN LOOP
    # ------------------------------------------------------
    def run(self):
        print("AUTONOMOUS OBSTACLE-AVOIDING ROBOT ACTIVE\n")

        while self.step(self.time_step) != -1:

            dt = self.time_step / 1000.0
            hazards = self.get_lidar_sectors()

            # --- Collision Prevention ---
            danger = (hazards["FRONT"] < self.HAZARD_DISTANCE or 
                      hazards["LEFT"] < self.HAZARD_DISTANCE or 
                      hazards["RIGHT"] < self.HAZARD_DISTANCE)
            worker_hazard = False
                      
            # STATE MACHINE
            linear_v = 0
            angular_v = 0

            if self.state == "FORWARD":
                if danger or worker_hazard:
                    print("⚠️ Obstacle or worker hazard! Choosing safer direction...\n")

                    # choose direction with MAX distance
                    best_dir = max(hazards, key=hazards.get)

                    if best_dir == "LEFT":
                        self.turn_target = self.theta + math.pi/4
                    elif best_dir == "RIGHT":
                        self.turn_target = self.theta - math.pi/4
                    else:
                        self.turn_target = self.theta + math.pi

                    self.state = "TURN"
                else:
                    linear_v = self.SPEED

            elif self.state == "TURN":
                if self.turn_target is None:
                    self.state = "FORWARD"
                else:
                    angular_v, done = self.smooth_turn(self.turn_target, dt)
                    if done:
                        print("✔ Turn complete. Moving forward.\n")
                        self.turn_target = None
                        self.state = "FORWARD"
          
            # --- CURRENT SPEED & DYNAMIC SAFETY RADIUS ---
            current_speed = abs(linear_v)
            speed_ratio = min(current_speed / self.MAX_SPEED, 1.0)
            dynamic_safe_radius = (
                self.MIN_SAFE_RADIUS
                + speed_ratio * (self.MAX_SAFE_RADIUS - self.MIN_SAFE_RADIUS)
            )  
            # --- MANY WORKERS HAZARD CHECK ---
            worker_hazard = False
            closest_worker_dist = None

            for w in self.workers:
                w_pos = w["trans"].getSFVec3f()
                wx, wy = w_pos[0], w_pos[1]
                w["x"], w["y"] = wx, wy
                w["path"].append((wx, wy))

                dist = math.hypot(wx - self.x, wy - self.y)

                if closest_worker_dist is None or dist < closest_worker_dist:
                    closest_worker_dist = dist

                if dist < dynamic_safe_radius:
                    worker_hazard = True
                    
            # --- UPDATE POSE ---
            self.theta += angular_v * dt
            self.x += linear_v * math.cos(self.theta) * dt
            self.y += linear_v * math.sin(self.theta) * dt

            # normalize angle
            if self.theta > math.pi: self.theta -= 2*math.pi
            if self.theta < -math.pi: self.theta += 2*math.pi

            # APPLY MOTION
            self.trans_field.setSFVec3f([self.x, self.y, self.LOCKED_Z])
            self.rot_field.setSFRotation([0, 0, 1, self.theta])

            # ---------- STEP 7: LOG HAZARDS (ADDED) ----------
            sim_time = self.getTime()
            front = hazards["FRONT"]
            left = hazards["LEFT"]
            right = hazards["RIGHT"]
            danger_flag = int(danger)
            worker_flag = int(worker_hazard)
            closest_d = closest_worker_dist if closest_worker_dist is not None else -1.0

            self.log_file.write(f"{sim_time},{self.x},{self.y},{self.theta},"
                                f"{front},{left},{right},{danger_flag},{worker_flag},{closest_d},{self.state}\n")
            self.log_file.flush()
            # -------------------------------------------------

    # optional: close file when simulation ends (Webots may kill process abruptly, so this is best-effort)
    def __del__(self):
        try:
            self.log_file.close()
        except:
            pass

# Run the robot
controller = KinematicRobot()
controller.run()